## DIU - Practica1, entregables

- Desk research: Análisis Competencia
- 2 Personas
- 2 User Journey Map  ( 1 por persona)
- Revisión de Usabilidad

Prácticas Diseño Interfaces de Usuario 2020-21 (Tema: Turismo)

Grupo: DIU2_01Jmm.  Curso: 2020/21
Updated: 8/2/2021

Proyecto: JMM

Descripción: JMM

Miembros
 * :bust_in_silhouette:   Juan Mota Martínez     :octocat: JuamMM

-----





# Proceso de Diseño

## Paso 1. UX Desk Research & Analisis

![Método UX](../img/Competitive.png) 1.a Competitive Analysis
-----

Se ha elegido turgranada debido a que se trata de una la plataforma del propio ayuntamiento que se centra en viajes turísticos en la  ciudad de granada, y se ha considerado que se puede evaluar mejor la calidad de la misma debido a que al vivir en dicha ciudad se conoce de primera mano los viajes que oferta.

![Método UX](../img/Persona.png) 1.b Persona
-----

Jose Antonio, está pensado para representar un pequeño sector de personas que trabajan en la ciudad pero por diversos motivos no han podido disfrutar de la misma.

![Método UX](../img/JTP.png)

Patricia Torres, representa al conjunto de estudiantes que han tenido que mudarse a granada a estudiar y no conocen nada de la ciudad.

![Método UX](../img/PTT.png)

![Método UX](../img/JourneyMap.png) 1.c User Journey Map
----

No son habituales puesto que no es normal que una única persona se encarge de toda la planificación. Se ha tratado de representar como reaccionan dos personas sin experiencia organizando excursiones.

![Método UX](../img/JALJM.png)

![Método UX](../img/PTJM.png)

![Método UX](../img/usabilityReview.png) 1.d Usability Review
----
La página funciona bien en general, sin embargo existen algunos fallos como en el sistema de búsqueda y el soporte de usuario

La nota obtenida ha sido un 77 (Good)
